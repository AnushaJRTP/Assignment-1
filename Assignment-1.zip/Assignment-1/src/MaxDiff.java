
public class MaxDiff {
  public static void main(String[] args) {
    int[] my_array = { 9, 2, 12, 5, 4, 7, 3, 19, 5};
    int minEle = my_array[0]; 
    int maxEle = my_array[0]; 
    for (int i = 1; i < my_array.length; i++) { 
        minEle = Math.min(minEle, my_array[i]); 
        maxEle = Math.max(maxEle, my_array[i]); 
    } 

   System.out.println("The maximum difference is between "+minEle+" and "+maxEle+" is "+(maxEle - minEle));
  }
}
