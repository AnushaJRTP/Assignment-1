
public class MinMax {

  public static void main(String[] args) {
    int[] my_array = {1, 2, 5, 5, 6, 6, 7, 2};
    int minEle = my_array[0]; 
    int maxEle = my_array[0]; 
    for (int i = 1; i < my_array.length; i++) { 
        minEle = Math.min(minEle, my_array[i]); 
        maxEle = Math.max(maxEle, my_array[i]); 
    } 

    System.out.println("Min " +minEle+" and Max "+maxEle); 
  }

}
