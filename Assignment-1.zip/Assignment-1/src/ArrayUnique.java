
public class ArrayUnique {

  public static void main(String[] args) {
 int[] my_array = {1, 6, 4, 3, 2, 2, 3, 8, 1};
    
 for(int i=0;i<my_array.length;i++)
 {   
     int flag = 0;
    for(int j=0;j<my_array.length;j++)
     {
         if(i!=j)
         {
             if(my_array[i]==my_array[j])
             {
                 flag=1;
                 break;
             }

         }
     }
     if(flag==0)
     {
         System.out.print(my_array[i]);
         System.out.print(",");
     }
 }
  }
}
