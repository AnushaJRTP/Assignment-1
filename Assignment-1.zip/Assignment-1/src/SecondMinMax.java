
public class SecondMinMax {

  public static void main(String[] args) {
    int temp; 
    int[] my_array = {1, 2, 5, 9, 6, 4, 7, 2};
    for (int i = 0; i < my_array.length; i++) 
    {
        for (int j = i + 1; j < my_array.length; j++) 
        {
            if (my_array[i] > my_array[j]) 
            {
                temp = my_array[i];
                my_array[i] = my_array[j];
                my_array[j] = temp;
            }
        }
    }
    System.out.println("Second Largest:"+my_array[(my_array.length)-2]);
    System.out.println("Second Smallest:"+my_array[1]);
}

}
