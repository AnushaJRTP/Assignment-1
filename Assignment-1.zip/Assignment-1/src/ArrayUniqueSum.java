import java.util.LinkedHashSet;
import java.util.Set;

public class ArrayUniqueSum {

  public static void main(String[] args) {
    int[] my_array = {1, 6, 4, 3, 2, 2, 3, 8, 1};
    sumOfUnique(my_array);
    int[] my_array2 = {1, 1, 3, 2, 2, 3};
    sumOfUnique(my_array2);
   }
  public static void sumOfUnique(int[] my_array) {
    
    Set<Integer> distinctElements = new LinkedHashSet<Integer>();
    for(int i=0;i<my_array.length;i++){
      distinctElements.add(my_array[i]);
    }
    int sum = 0;
    for (Integer e : distinctElements) 
      sum += e;
    System.out.println("Elements "+distinctElements);
    System.out.println("Sum of elements "+sum);
  }
}
