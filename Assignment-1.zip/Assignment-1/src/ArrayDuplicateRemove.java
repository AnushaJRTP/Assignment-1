import java.util.LinkedHashSet;
import java.util.Set;

public class ArrayDuplicateRemove {
  public static void main(String[] args) {
    int[] my_array = {1, 2, 5, 5, 6, 6, 7, 2};
  Set<Integer> distinctElements = new LinkedHashSet<Integer>();
  for(int i=0;i<my_array.length;i++){
    distinctElements.add(my_array[i]);
  }
  System.out.println(distinctElements);
  }
}
