
public class ThirdLargestNumber {

  public static void main(String[] args) {
    int[] my_array = {6, 8, 1, 9, 2, 1, 10, 12};
    thirdLargestElement(my_array);
    int[] my_array2= { 6, 8, 1, 9, 2, 1, 10};
    thirdLargestElement(my_array2);
    int[] my_array3= {6};
    thirdLargestElement(my_array3);
    }  
public static String thirdLargestElement(int[] my_array) {
  if(my_array.length < 3){
  System.out.println("array should be more than 3 elements");
  return "error";
  }
  int temp;  
  for (int i = 0; i < my_array.length; i++)   
  {  
      for (int j = i + 1; j < my_array.length; j++)   
      {  
          if (my_array[i] > my_array[j])   
          {  
              temp = my_array[i];  
              my_array[i] = my_array[j];  
              my_array[j] = temp;  
          }  
      }  
  }  
 System.out.println(my_array[ my_array.length-3]);  
 return "success";
}
  }

